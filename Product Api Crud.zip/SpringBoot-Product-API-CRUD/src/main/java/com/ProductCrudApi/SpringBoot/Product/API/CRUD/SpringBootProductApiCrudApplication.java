package com.ProductCrudApi.SpringBoot.Product.API.CRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProductApiCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductApiCrudApplication.class, args);
		System.out.println("SpringBOOT....");
	}

}
