package com.ProductCrudApi.SpringBoot.Product.API.CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductApiCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
